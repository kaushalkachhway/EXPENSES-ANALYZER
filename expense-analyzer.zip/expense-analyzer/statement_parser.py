#!/usr/bin/env python3
"""
Milestone 1 - Core statement parser.

Usage:
    python statement_parser.py statement.pdf
    python statement_parser.py export.csv
    python statement_parser.py receipt.jpg          # needs tesseract installed
    python statement_parser.py statement.pdf --json out.json

Install:
    pip install pdfplumber pandas pytesseract pillow pdf2image

Pipeline: extract text/rows -> parse -> redact -> normalize merchant ->
          rule-based categorize -> dedupe hash -> anomaly flags -> print.
Unknown merchants are marked "Uncategorized" (Milestone 3 sends only those to an LLM).
"""
import argparse, hashlib, io, json, re, statistics, sys
from collections import defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------- model
@dataclass
class Txn:
    date: str                 # ISO yyyy-mm-dd
    raw_description: str
    amount: float             # always positive
    type: str                 # "debit" | "credit"
    merchant: str = ""
    category: str = "Uncategorized"
    hash: str = ""
    flags: list = None

# ---------------------------------------------------------------- redaction (privacy-first)
REDACTIONS = [
    (re.compile(r"\b\d{9,18}\b"), "[ACCT]"),                          # account / card numbers
    (re.compile(r"\b(?:\d[ -]?){13,16}\b"), "[CARD]"),
    (re.compile(r"(?<!\d)(?:\+?91[- ]?)?[6-9]\d{9}(?!\d)"), "[PHONE]"),  # Indian mobiles
    (re.compile(r"\b[\w.+-]+@(?!ok|ybl|paytm|axl|ibl|sbi)[\w-]+\.[\w.]+\b"), "[EMAIL]"),
    (re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b"), "[PAN]"),
]
def redact(text: str) -> str:
    for rx, token in REDACTIONS:
        text = rx.sub(token, text)
    return text

# ---------------------------------------------------------------- extraction
DATE_FORMATS = ["%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%d-%m-%y", "%d %b %Y",
                "%d-%b-%Y", "%d %b %y", "%Y-%m-%d", "%m/%d/%Y"]
DATE_RX = r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{1,2}[ -][A-Za-z]{3}[ -]\d{2,4}|\d{4}-\d{2}-\d{2}"
# date  description  amount  [balance]   (amount may carry Dr/Cr or +/-)
LINE_RX = re.compile(
    rf"^(?P<date>{DATE_RX})\s+(?P<desc>.+?)\s+"
    r"(?P<amt>[-+]?[\d,]+\.\d{2})\s*(?P<drcr>Dr|Cr|DR|CR)?"
    r"(?:\s+(?P<bal>[\d,]+\.\d{2})\s*(?:Dr|Cr|DR|CR)?)?$")

def parse_date(s: str) -> Optional[str]:
    s = s.strip()
    for f in DATE_FORMATS:
        try:
            return datetime.strptime(s, f).date().isoformat()
        except ValueError:
            pass
    return None

def to_float(s) -> float:
    return float(str(s).replace(",", "").replace("₹", "").replace("Rs.", "").strip() or 0)

def pdf_text(path: str) -> str:
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        pages = [p.extract_text() or "" for p in pdf.pages]
    text = "\n".join(pages)
    if len(text.strip()) < 50:             # scanned PDF -> OCR fallback
        from pdf2image import convert_from_path
        import pytesseract
        text = "\n".join(pytesseract.image_to_string(im) for im in convert_from_path(path, dpi=300))
    return text

def image_text(path: str) -> str:
    import pytesseract
    from PIL import Image
    return pytesseract.image_to_string(Image.open(path))

def parse_text_lines(text: str) -> list[Txn]:
    out, prev_bal = [], None
    for line in (l.strip() for l in text.splitlines()):
        m = LINE_RX.match(line)
        if not m:
            continue
        date = parse_date(m["date"])
        if not date:
            continue
        amt, drcr = to_float(m["amt"]), (m["drcr"] or "").lower()
        bal = to_float(m["bal"]) if m["bal"] else None
        if drcr:
            typ = "debit" if drcr == "dr" else "credit"
        elif m["amt"].startswith("-"):
            typ = "debit"
        elif m["amt"].startswith("+"):
            typ = "credit"
        elif bal is not None and prev_bal is not None:   # infer from running balance
            typ = "credit" if bal > prev_bal else "debit"
        else:
            typ = "debit"
        prev_bal = bal if bal is not None else prev_bal
        out.append(Txn(date, m["desc"], abs(amt), typ))
    return out

def parse_csv(path: str) -> list[Txn]:
    import pandas as pd
    df = pd.read_csv(path)
    cols = {c.lower().strip(): c for c in df.columns}
    pick = lambda *names: next((cols[n] for n in names if n in cols), None)
    c_date = pick("date", "txn date", "transaction date", "value date")
    c_desc = pick("description", "narration", "details", "particulars", "remarks")
    c_amt, c_dr = pick("amount"), pick("debit", "withdrawal", "withdrawal amt.", "debit amount")
    c_cr = pick("credit", "deposit", "deposit amt.", "credit amount")
    if not (c_date and c_desc):
        sys.exit(f"Could not detect date/description columns in: {list(df.columns)}")
    out = []
    for _, r in df.iterrows():
        d = parse_date(str(r[c_date]))
        if not d:
            continue
        if c_dr or c_cr:
            dr = to_float(r[c_dr]) if c_dr and str(r[c_dr]) != "nan" else 0
            cr = to_float(r[c_cr]) if c_cr and str(r[c_cr]) != "nan" else 0
            amt, typ = (dr, "debit") if dr else (cr, "credit")
        else:
            v = to_float(r[c_amt]); amt, typ = abs(v), ("debit" if v < 0 else "credit")
        if amt:
            out.append(Txn(d, str(r[c_desc]), amt, typ))
    return out

def extract(path: str) -> list[Txn]:
    ext = Path(path).suffix.lower()
    if ext == ".csv":
        return parse_csv(path)
    if ext == ".pdf":
        return parse_text_lines(pdf_text(path))
    if ext in {".jpg", ".jpeg", ".png", ".webp"}:
        return parse_text_lines(image_text(path))   # receipts often need a custom parser; see README notes
    sys.exit(f"Unsupported file type: {ext}")

# ---------------------------------------------------------------- merchant normalization + rules
# (regex on cleaned description, canonical merchant, category)
MERCHANTS = [
    (r"swiggy",               "Swiggy",        "Dining"),
    (r"zomato",               "Zomato",        "Dining"),
    (r"starbucks|cafe|restaurant", "Cafe/Restaurant", "Dining"),
    (r"bigbasket|blinkit|zepto|dmart|grofers|instamart", "Grocery Delivery/Store", "Groceries"),
    (r"amazon|amzn",          "Amazon",        "Shopping"),
    (r"flipkart",             "Flipkart",      "Shopping"),
    (r"uber",                 "Uber",          "Transport"),
    (r"ola\b|olacabs|rapido", "Ola/Rapido",    "Transport"),
    (r"irctc",                "IRCTC",         "Transport"),
    (r"netflix",              "Netflix",       "Subscriptions"),
    (r"spotify",              "Spotify",       "Subscriptions"),
    (r"hotstar|prime video|youtube ?premium|apple\.com/bill|google ?play", "Digital Subscription", "Subscriptions"),
    (r"airtel|jio|vodafone|\bvi\b|bsnl", "Telecom", "Utilities"),
    (r"electricity|bescom|mseb|bses|tneb|mpeb|gas bill|water bill", "Utility Bill", "Utilities"),
    (r"rent|landlord",        "Rent",          "Rent"),
    (r"salary|payroll",       "Salary",        "Income"),
    (r"emi|loan",             "Loan EMI",      "Loan/EMI"),
    (r"atm|cash wdl",         "ATM Withdrawal","Cash"),
]
NOISE = re.compile(r"\b(upi|imps|neft|rtgs|pos|ecom|ach|nach|ref|txn|debit|credit|payment|to|from|by)\b|[-/_*:]|\b\d{4,}\b|\[\w+\]", re.I)

def clean(desc: str) -> str:
    return re.sub(r"\s+", " ", NOISE.sub(" ", desc)).strip()

def categorize(t: Txn) -> None:
    desc = t.raw_description.lower()
    for rx, merchant, cat in MERCHANTS:
        if re.search(rx, desc):
            t.merchant, t.category = merchant, cat
            break
    else:
        t.merchant = clean(t.raw_description).title() or "Unknown"
    if t.type == "credit" and t.category == "Uncategorized":
        t.category = "Income"

# ---------------------------------------------------------------- dedupe hash
def make_hash(t: Txn) -> str:
    norm = re.sub(r"\s+", " ", t.raw_description.lower())
    key = f"{t.date}|{t.amount:.2f}|{t.type}|{norm}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]

def dedupe(txns: list[Txn]) -> tuple[list[Txn], int]:
    seen, out = set(), []
    for t in txns:
        t.hash = make_hash(t)
        if t.hash in seen:
            continue
        seen.add(t.hash); out.append(t)
    return out, len(txns) - len(out)

# ---------------------------------------------------------------- anomaly + subscription detection
def detect_anomalies(txns: list[Txn]) -> None:
    for t in txns:
        t.flags = []
    debits = [t for t in txns if t.type == "debit"]
    # 1) unusually large one-off: > mean + 3*stdev of the user's debits, and above a floor
    amts = [t.amount for t in debits]
    if len(amts) >= 10:
        mu, sd = statistics.mean(amts), statistics.pstdev(amts)
        for t in debits:
            if t.amount > mu + 3 * sd and t.amount > 5000:
                t.flags.append(f"large_purchase (>{mu + 3*sd:,.0f})")
    # 2) possible duplicate charge: same merchant+amount within 2 days (different raw refs)
    by_key = defaultdict(list)
    for t in debits:
        by_key[(t.merchant, t.amount)].append(t)
    for group in by_key.values():
        group.sort(key=lambda x: x.date)
        for a, b in zip(group, group[1:]):
            gap = (datetime.fromisoformat(b.date) - datetime.fromisoformat(a.date)).days
            if gap <= 2:
                b.flags.append("possible_duplicate_charge")
    # 3) recurring + price hike: same merchant ~monthly (25-35 day gaps) at least 3 times
    by_merchant = defaultdict(list)
    for t in debits:
        by_merchant[t.merchant].append(t)
    for m, group in by_merchant.items():
        group.sort(key=lambda x: x.date)
        if len(group) < 3:
            continue
        gaps = [(datetime.fromisoformat(b.date) - datetime.fromisoformat(a.date)).days for a, b in zip(group, group[1:])]
        if all(25 <= g <= 35 for g in gaps):
            for t in group:
                t.flags.append("recurring")
            for a, b in zip(group, group[1:]):
                if b.amount > a.amount * 1.05:
                    b.flags.append(f"price_hike ({a.amount:,.2f} -> {b.amount:,.2f})")

# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--json", help="also write rows to this JSON file")
    args = ap.parse_args()

    txns = extract(args.file)
    for t in txns:
        t.raw_description = redact(t.raw_description)   # redact BEFORE anything leaves the machine
        categorize(t)
    txns, dupes = dedupe(txns)
    detect_anomalies(txns)
    txns.sort(key=lambda t: t.date)

    print(f"{'DATE':<11}{'TYPE':<7}{'AMOUNT':>12}  {'MERCHANT':<24}{'CATEGORY':<15}FLAGS")
    print("-" * 90)
    for t in txns:
        print(f"{t.date:<11}{t.type:<7}{t.amount:>12,.2f}  {t.merchant[:23]:<24}{t.category:<15}{', '.join(t.flags)}")
    spent = sum(t.amount for t in txns if t.type == "debit")
    earned = sum(t.amount for t in txns if t.type == "credit")
    unk = sum(t.category == "Uncategorized" for t in txns)
    print(f"\n{len(txns)} transactions | debits {spent:,.2f} | credits {earned:,.2f} | "
          f"duplicates dropped {dupes} | need LLM categorization: {unk}")
    if args.json:
        Path(args.json).write_text(json.dumps([asdict(t) for t in txns], indent=2))

if __name__ == "__main__":
    main()
